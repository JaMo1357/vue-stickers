const assert = require('chai').assert;
const store = require('../../../src/stores/StickerStore/index');

console.log('store', store);

/*describe('App', function(){

  it('should create new object in store', function(){
    //assert.equal()
  });

});*/
